import React from 'react';
import { SafeAreaView } from 'react-native';

const index=(props)=> {
    return (
        <SafeAreaView>
            
        </SafeAreaView>
    );
}

export default index;